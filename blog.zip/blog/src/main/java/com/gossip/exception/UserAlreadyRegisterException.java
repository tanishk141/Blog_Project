package com.gossip.exception;

public class UserAlreadyRegisterException extends RuntimeException {

	public UserAlreadyRegisterException(String msg) {
		super(msg);
	}
	
}
